#include <iostream>
#include <string>
using namespace std;

struct Shape {
    double length;
    double width;
    double height;
    double radius;
    double base;
};
int main() {
     Shape s;
    double area;

    // Rectangle
    cout << "RECTANGLE" << endl;
    cout << "Enter length: ";
    cin >> s.length;
    cout << "Enter width: ";
    cin >> s.width;

    area = s.length * s.width;
    cout << "Area of Rectangle = " << area << endl;

    // Circle
    cout << "\nCIRCLE" << endl;
    cout << "Enter radius: ";
    cin >> s.radius;

    area = 3.142 * s.radius * s.radius;
    cout << "Area of Circle = " << area << endl;

     // Cuboid
    cout << "\nCUBOID" << endl;
    cout << "Enter length: ";
    cin >> s.length;
    cout << "Enter width: ";
    cin >> s.width;
    cout << "Enter height: ";
    cin >> s.height;

    area = 2 * (s.length * s.width +
                s.length * s.height +
                s.width * s.height);

    cout << "Surface Area of Cuboid = " << area << endl;

    // Triangle
    cout << "\nTRIANGLE" << endl;
    cout << "Enter base: ";
    cin >> s.base;
    cout << "Enter height: ";
    cin >> s.height;

    area = 0.5 * s.base * s.height;
    cout << "Area of Triangle = " << area << endl;



    return 0;
}
