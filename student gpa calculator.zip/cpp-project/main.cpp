#include <iostream>
#include <string>
using namespace std;
struct Student {
    string name;
    string id;
    double grades[5];
    int numCourses;
    double gpa;
    bool registered;
};

// GPP Function
double calculateGPA(Student s) {
    double total = 0;

    for (int i = 0; i < s.numCourses; i++) {
        total += s.grades[i];
    }

    return total / s.numCourses;
}

// Function to display student details
void displayStudent(Student s) {
    cout << "STUDENT CURRENT TRANSCRIPT."<< endl;
    cout << "Name: " << s.name << endl;
    cout << "ID: " << s.id << endl;
    cout << "Registered: " << (s.registered ? "Yes" : "No") << endl;

    cout << "Grades: ";
    for (int i = 0; i < s.numCourses; i++) {
        cout << s.grades[i] << " ";
    }

    cout << "GPA: " << s.gpa << endl;
    
}

int main() {
     Student student;

    // Create student
    cout << "Enter student name: ";
    getline(cin, student.name);

    cout << "Enter student ID: ";
    getline(cin, student.id);

    cout << "Is the student registered? (1 = Yes, 0 = No): ";
    cin >> student.registered;

    cout << "Enter number of courses: ";
    cin >> student.numCourses;

    // Enter grades
    for (int i = 0; i < student.numCourses; i++) {
        cout << "Enter grade for course " << i + 1 << ": ";
        cin >> student.grades[i];
    }

    // Calculate GPA
    student.gpa = calculateGPA(student);

    // Display result
    displayStudent(student);

    return 0;
}
